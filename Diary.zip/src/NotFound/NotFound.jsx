import s from '../NotFound/styles.module.css'

const NotFound = () => {
  return (
    <div className={s.main}> 
      <div className={s.center}>
        <h1>404</h1>
        <h2>PAGE NOT FOUND</h2>
        <a href="#"> go to homepage</a>
      </div>
    </div>
  )
}

export default NotFound