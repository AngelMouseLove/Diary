import React from 'react';
import NotFound from '../../NotFound/NotFound';

function NotFoundPage() {
  return (
    <div>
      <NotFound/>
    </div>
  );
}

export default NotFoundPage;

