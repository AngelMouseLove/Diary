export const MAX_CARD_BODY_LENGTH = 250;
export const DATE_PATTERN = 'DD.MM.YYYY';